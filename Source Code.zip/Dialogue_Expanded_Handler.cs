using HarmonyLib;
using UnityEngine;
using System.Collections.Generic;
using System.IO;
using BepInEx;
using System.Text.RegularExpressions;
using System;
using Microsoft.Win32.SafeHandles;
using System.Collections;
using System.Xml.XPath;
using System.Diagnostics;
using Debug = UnityEngine.Debug;

namespace Project_Dialogue_Expanded
{
    [HarmonyPatch(typeof(SocialTabManager), "GetDialogueState")] // Patch to change dialogue state sorting method 
    public class Patch_GetDialogueState
    {
        public static void Postfix(int characterID, SocialTabManager __instance, ref int __result)
        {
             Debug.Log($"[DialogueExpanded] GetRandomDialogueState called. CharacterID: {characterID}");

             if (characterID != 101 && characterID != 102 && characterID != 108)
            {
                Debug.Log($"[DialogueExpanded] Vanilla NPC detected. Normal routine applied.");
                return;
            }

            Debug.Log($"[DialogueExpanded] GetDialogueState called for modified NPC.");

            RelationshipStatus relationshipDataOrLog = __instance.GetRelationshipData(characterID);
            
            if (relationshipDataOrLog == null)
            {
                return;
            }

            int level = relationshipDataOrLog.relationshipLevel;

            __result = level switch
            {
                1 => UnityEngine.Random.Range(1,11),
                2 => UnityEngine.Random.Range(11,21),
                3 => UnityEngine.Random.Range(21,31),
                4 => UnityEngine.Random.Range(31,41),
                5 => UnityEngine.Random.Range(41,51),
                6 => UnityEngine.Random.Range(51,61),
                _ => __result,
            };
            
            Debug.Log($"[DialogExpanded] New state select: {__result}");

            if (__result >= 7)
            {
                Debug.Log("[DialogueExpanded] GetDialogueState select custom dialogue.");
            }

        }
    }

   [HarmonyPatch(typeof(CSVLoader), "GetDictionaryValues")]
    public class Patch_GetDictionaryValues // Patch to find dialogue string for the state sorted
    {
        public static void Postfix(int textType, ref Dictionary<string, string> __result)
        {
            Debug.Log("[DialogueExpanded] GetDictionaryValues called.");
            if (textType == 1)
            {
                string path = Path.Combine(Paths.PluginPath, "Project_Dialogue_Expanded", "Project_Dialogue_Expanded.txt");

                if (!File.Exists(path))
                {
                    Debug.Log($"[DialogueExpanded] Error - File not found: '{path}'");
                    return;
                }

                try
                {
                    string[] lines = File.ReadAllLines(path); // From original module
                    Regex csvSplitRegex = new Regex(",(?=(?:[^\"]*\"[^\"]*\")*(?![^\"]*\"))");  // From original module

                    int linesAdd = 0;

                    string[] header = csvSplitRegex.Split(lines[0].TrimEnd('\r'));


                    for (int i = 0; i < header.Length; i++)  // Define header and register columns name
                    {
                        header[i] = header[i].Trim().Trim('"');
                    }

                    int animator_index = -1;

                    for (int i = 0; i < header.Length; i++)  // Search for animation column and save it's index
                    {
                        if (string.Equals(header[i], "portrait_animator", StringComparison.OrdinalIgnoreCase)) // If the cell valor is "portrait_animator", save it's number 
                        {
                            animator_index = i;
                            break;  // Stop loop if the valor was found
                        }
                    }

                    for (int j = 1; j < lines.Length; j++) // Parse every dialogue line added
                    {
                        string line = lines[j];
                        if (string.IsNullOrWhiteSpace(line)) continue;

                        string[] parts = csvSplitRegex.Split(line.TrimEnd('\r'));
                        for (int i = 0; i < parts.Length; i++)
                        {
                            parts[i] = parts[i].Trim().Trim('"');
                        }

                        if (parts.Length >= 2 && !string.IsNullOrEmpty(parts[0]))  // If the dialogue lines are found, separate language key and dialog 
                        {
                            string key = parts[0];
                            string text = parts[1];
                            
                            if (animator_index >= 0 && animator_index < parts.Length) // If there are animators, found them in the column and add it to the text
                            {
                                string animator = parts[animator_index];
                                if (!string.IsNullOrEmpty(animator))
                                {
                                    text = "[anim=" + animator + "]" + text;
                                }
                            }
                            __result[key] = text; // Return english dialogue text for state sorted 
                            linesAdd++;
                        }
                    }
                    
                    Debug.Log($"[DialogExpanded] {linesAdd} added to the game");
                }
                catch (Exception e)
                {
                    Debug.Log($"[DialogExpanded] Error - line couldn't be add {e.Message}");
                }
            }
        }
    }
    [HarmonyPatch(typeof(DialogueManager), "CasualDialogue")]
    public class Patch_CasualDialogue // Patch to allow the game to find text string for dialogue chain
    {
        static AccessTools.FieldRef<DialogueManager, MajorNPC> majorNPCRef = 
        AccessTools.FieldRefAccess<DialogueManager, MajorNPC>("majorNPC");
        static bool Prefix(int state, ref string __result, DialogueManager __instance)
        {
            MajorNPC majorNPC = majorNPCRef(__instance);
            Debug.Log("[DialogueExpanded] CasualDialogue patched called.");

            int zeroBased = state - 1;
            int x = (zeroBased/10) + 1;
            int y = (zeroBased % 10) + 1;

            if (y >= 7 && y <= 10)
            {
                string key = majorNPC.NPCName + $"_interaction{x}_{y}";
                __result = LocalizationSystem.GetLocalisedValue(key, 1);
                Debug.Log($"[DialogueExpanded] state = {state}, x = {x}, y = {y}, key = '{key}'");
                Debug.Log($"[DialogueExpanded] Verifying if result was found: {__result}");

                if(string.IsNullOrWhiteSpace(__result))
                {
                    Debug.Log($"[DialogueExpanded] Error - {key} not found. Implementing conditional for introKey");
                    string introKey = key + "_intro";
                    Debug.Log($"[DialogueExpanded] Starting search for {introKey}");
                    string introText = LocalizationSystem.GetLocalisedValue(introKey, 1);
                    Debug.Log($"[DialogueExpanded] {introText} found. Adding it to __result");
                    __result = introText;

                } 
                Debug.Log($"[DialogueExpanded] CasualDialogue patched called. __result = '{__result}'");
                return false;
            }
            Debug.Log($"[DialogueExpanded] CasualDialogue patched called. Patch not used.");
            return true;
        }
    }

    [HarmonyPatch(typeof(NPCConversation), "OpenDialogueWindow")]

    public class Patch_HasQuestionButton // Patch to allow new custom dialogue chain
    {
        static AccessTools.FieldRef<NPCConversation, int> textStateRef = 
        AccessTools.FieldRefAccess<NPCConversation, int>("textState");

        static AccessTools.FieldRef<NPCConversation, bool> hasQuestionButtonRef = 
        AccessTools.FieldRefAccess<NPCConversation, bool>("hasQuestionButton");

        static void Postfix
        (
            NPCConversation __instance,
            Dialogue dialogue,
            MajorNPC major,
            int festivalChat,
            ProgressionDialogueType progressionDialogue,
            string customerOverrideText
        )

        {
            Debug.Log($"[DialogueExpanded] HasQuestionButton patched called.");
            if (major == null) return;
            if (customerOverrideText != "" && PlayStaticStats.RestaurantDialogueOverlayActive) return;
            if (dialogue != null) return;
            if (PlayStaticStats.PlayingCutscene) return;
            if (festivalChat > 0) return;
            if (progressionDialogue != ProgressionDialogueType.None) return;
            if (major.MajorCharacterID == 127 && PlayStaticStats.CurrentCity == E_City.WhiteAshHarbor) return;
            Debug.Log($"[DialogueExpanded] Normal dialogue options returned.");

            int textState = textStateRef(__instance);
            if (textState <= 0) return;

            if (textState == 11 || textState == 21 || textState == 31 || textState == 41 || textState == 51)
            {
                Debug.Log($"[DialogueExpanded] Normal intro dialogue returned.");
                return;
            }

            int zeroBased = textState - 1;
            int x = (zeroBased / 10) + 1;
            int y = (zeroBased % 10) + 1;
            if (y >= 7 && y <= 10)
            {
                Debug.Log($"[DialogueExpanded] Verifying for introText");
                string introKey = major.NPCName + $"_interaction{x}_{y}_intro";
                string introText = LocalizationSystem.GetLocalisedValue(introKey, 1);

                if (!string.IsNullOrWhiteSpace(introText))
                {
                    hasQuestionButtonRef(__instance) = true;
                    Debug.Log($"[DialogueExpanded] Search done. hasQuestionButtonRef defined as true.");
                }
            }
        }
    }

    [HarmonyPatch(typeof(DialogueManager), "RelationshipLevelButtonText")]

    public class Patch_RelationshipLevelButtonText // Patch to allow custom dialogue options 
    {
        static AccessTools.FieldRef<DialogueManager, MajorNPC> majorNPCRef =
        AccessTools.FieldRefAccess<DialogueManager, MajorNPC>("majorNPC");

        static void Postfix(int state, DialogueManager __instance, ref string[] __result)
        {
            MajorNPC majorNPC = majorNPCRef(__instance);

            int zeroBased = state - 1;
            int x = (zeroBased / 10) + 1;
            int y = (zeroBased % 10) + 1;

            if (y >= 7 && y <= 10)
            {
                Debug.Log("[DialogueExpanded] RelationshipLevelButtonText patched called. Searching for localized value.");
                string[] array = new string[2];
                array[0] = LocalizationSystem.GetLocalisedValue(majorNPC.NPCName + $"_interaction{x}_{y}_option_1", 1);
                array[1] = LocalizationSystem.GetLocalisedValue(majorNPC.NPCName + $"_interaction{x}_{y}_option_2", 1);
                __result = array;
                Debug.Log($"[DialogueExpanded] RelationshipLevelButtonText patched called. Result = '{array}'");
            }
        }
    }

    [HarmonyPatch(typeof(DialogueManager), "RelationshipLevelResponse")]

    public class Patch_RelationshipLevelResponse  // Patch to allow NPC reply to option selected
    {
        static AccessTools.FieldRef<DialogueManager, MajorNPC> majorNPCRef =
        AccessTools.FieldRefAccess<DialogueManager, MajorNPC>("majorNPC");

        static void Postfix(int state, int textNumber, DialogueManager __instance, ref string __result)
        {
            MajorNPC majorNPC = majorNPCRef(__instance);

            int zeroBased = state - 1;
            int x = (zeroBased / 10) + 1;
            int y = (zeroBased % 10) + 1;

            if (y >= 7 && y <= 10)
            {
                Debug.Log($"[DialogueExpanded] RelationshipLevelResponse patched called. Dialogue switch opened: searching for {textNumber} option");
                switch (textNumber)
                {
                    case 1: __result = LocalizationSystem.GetLocalisedValue(majorNPC.NPCName + $"_interaction{x}_{y}_response_1", 1);
                    break;
                    case 2: __result = LocalizationSystem.GetLocalisedValue(majorNPC.NPCName + $"_interaction{x}_{y}_response_2", 1);
                    break;
                }
                Debug.Log($"[DialogueExpanded] RelationshipLevelResponse patched called. Result found: {__result}");
            }
        }
    }

    [HarmonyPatch(typeof(NPCConversation), "DialogueResponseButton1")]
    public class Patch_ResetTextNumber_Button1
    {
        static AccessTools.FieldRef<NPCConversation, int> currentTextNumberRef =
        AccessTools.FieldRefAccess<NPCConversation, int>("currentTextNumber");

        static void Prefix(NPCConversation __instance)
        {
            Debug.Log("[DialogExpanded] Patch_ResetTextNumber_Button1 called. TextNumber set to 0");
            currentTextNumberRef(__instance) = 0;
        }
    }

    [HarmonyPatch(typeof(NPCConversation), "DialogueResponseButton2")]
    public class Patch_ResetTextNumber_Button2
    {
        static AccessTools.FieldRef<NPCConversation, int> currentTextNumberRef =
        AccessTools.FieldRefAccess<NPCConversation, int>("currentTextNumber");

        static void Prefix(NPCConversation __instance)
        {
            Debug.Log("[DialogExpanded] Patch_ResetTextNumber_Button2 called. TextNumber set to 0");
            currentTextNumberRef(__instance) = 0;
        }
    }
}