using HarmonyLib;
using UnityEngine;
using System.Collections.Generic;
using System.IO;
using BepInEx;
using System.Text.RegularExpressions;
using System;
using Microsoft.Win32.SafeHandles;
using System.Collections;
using System.Xml.XPath;

namespace Uriel_Dialogue_Expanded
{
    [HarmonyPatch(typeof(SocialTabManager), "GetDialogueState")]
    public class Patch_GetDialogueState
    {
        public static void Postfix(int characterID, SocialTabManager __instance, ref int __result)
        {
             Debug.Log($"[DialogueExpanded] GetRandomDialogueState called for character: {characterID}");

             if (characterID != 101)
            {
                return;
            }

            Debug.Log($"[DialogueExpanded] GetDialogueState called for Uriel");

            RelationshipStatus relationshipDataOrLog = __instance.GetRelationshipData(characterID);
            
            if (relationshipDataOrLog == null)
            {
                return;
            }

            int level = relationshipDataOrLog.relationshipLevel;

            __result = level switch
            {
                1 => UnityEngine.Random.Range(1,11),
                2 => UnityEngine.Random.Range(11,21),
                3 => UnityEngine.Random.Range(21,31),
                4 => UnityEngine.Random.Range(31,41),
                5 => UnityEngine.Random.Range(41,51),
                6 => UnityEngine.Random.Range(51,61),
                _ => __result,
            };
            
            Debug.Log($"[DialogExpanded] New state select for Uriel: {__result}");

        }
    }

   [HarmonyPatch(typeof(CSVLoader), "GetDictionaryValues")]
    public class Patch_GetDictionaryValues
    {
        public static void Postfix(int textType, ref Dictionary<string, string> __result)
        {
            if (textType == 1)
            {
                string path = Path.Combine(Paths.PluginPath, "Uriel_Dialogue_Expanded", "Uriel_Dialogue_Expanded.txt");

                if (!File.Exists(path))
                {
                    Debug.Log($"[DialogueExpandend] Error - File not found: {path}");
                    return;
                }

                try
                {
                    string[] lines = File.ReadAllLines(path);
                    Regex csvSplitRegex = new Regex(",(?=(?:[^\"]*\"[^\"]*\")*(?![^\"]*\"))");

                    int linesAdd = 0;

                    foreach (string line in lines)
                    {
                        if (string.IsNullOrWhiteSpace(line)) continue;
                        
                        string[] parts = csvSplitRegex.Split(line);

                        for (int i = 0; i < parts.Length; i++)
                        {
                            parts[i] = parts[i].Trim().Trim('"');
                        }

                        if (parts.Length >= 2 && !string.IsNullOrEmpty(parts[0]))
                        {
                            string key = parts[0];
                            string text = parts[1];

                            __result[key] = text;
                            linesAdd++;
                        }
                    }
                    Debug.Log($"[DialogExpanded] {linesAdd} added to the game");
                }
                catch (Exception e)
                {
                    Debug.Log($"[DialogExpanded] Error - line couldn't be add {e.Message}");
                }
            }
        }
    }
    [HarmonyPatch(typeof(DialogueManager), "CasualDialogue")]
    public class Patch_CasualDialogue
    {
        static AccessTools.FieldRef<DialogueManager, MajorNPC> majorNPCRef = 
        AccessTools.FieldRefAccess<DialogueManager, MajorNPC>("majorNPC");
        static bool Prefix(int state, ref string __result, DialogueManager __instance)
        {
            MajorNPC majorNPC = majorNPCRef(__instance);

            int zeroBased = state - 1;
            int x = (zeroBased/10) + 1;
            int y = (zeroBased % 10) + 1;

            if (y >= 7 && y<= 10)
            {
                string key = majorNPC.NPCName + $"_interaction{x}_{y}";
                __result = LocalizationSystem.GetLocalisedValue(key, 1);

                if(string.IsNullOrWhiteSpace(__result))
                {
                    string introKey = key + "_intro";
                    string introText = LocalizationSystem.GetLocalisedValue(introKey, 1);
                    __result = introText;

                } 

                Debug.Log($"[DialogueExpanded] state = {state}, x = {x}, y = {y}, key = '{key}'");
                Debug.Log($"[DialogueExpanded] result = '{__result}'");
                return false;
            }
            return true;
        }
    }

    [HarmonyPatch(typeof(NPCConversation), "OpenDialogueWindow")]

    public class Patch_HasQuestionButton
    {
        static AccessTools.FieldRef<NPCConversation, int> textStateRef = 
        AccessTools.FieldRefAccess<NPCConversation, int>("textState");

        static AccessTools.FieldRef<NPCConversation, bool> hasQuestionButtonRef = 
        AccessTools.FieldRefAccess<NPCConversation, bool>("hasQuestionButton");

        static void Postfix
        (
            NPCConversation __instance,
            Dialogue dialogue,
            MajorNPC major,
            int festivalChat,
            ProgressionDialogueType progressionDialogue,
            string customerOverrideText
        )
        {
            if (major == null) return;
            if (customerOverrideText != "" && PlayStaticStats.RestaurantDialogueOverlayActive) return;
            if (dialogue != null) return;
            if (PlayStaticStats.PlayingCutscene) return;
            if (festivalChat > 0) return;
            if (progressionDialogue != ProgressionDialogueType.None) return;
            if (major.MajorCharacterID == 127 && PlayStaticStats.CurrentCity == E_City.WhiteAshHarbor) return;

            int textState = textStateRef(__instance);
            if (textState <= 0) return;

            if (textState == 11 || textState == 21 || textState == 31 || textState == 41 || textState == 51) return;

            int zeroBased = textState - 1;
            int x = (zeroBased / 10) + 1;
            int y = (zeroBased % 10) + 1;

            if (y >= 7 && y <= 10)
            {
                string introKey = major.NPCName + $"_interaction{x}_{y}_intro";
                string introText = LocalizationSystem.GetLocalisedValue(introKey, 1);

                if (!string.IsNullOrWhiteSpace(introText))
                {
                    hasQuestionButtonRef(__instance) = true;
                }
            }
        }
    }

    [HarmonyPatch(typeof(DialogueManager), "RelationshipLevelButtonText")]

    public class Patch_RelationshipLevelButtonText
    {
        static AccessTools.FieldRef<DialogueManager, MajorNPC> majorNPCRef =
        AccessTools.FieldRefAccess<DialogueManager, MajorNPC>("majorNPC");

        static void Postfix(int state, DialogueManager __instance, ref string[] __result)
        {
            MajorNPC majorNPC = majorNPCRef(__instance);

            int zeroBased = state - 1;
            int x = (zeroBased / 10) + 1;
            int y = (zeroBased % 10) + 1;

            if (y >= 7 && y <= 10)
            {
                string[] array = new string[2];
                array[0] = LocalizationSystem.GetLocalisedValue(majorNPC.NPCName + $"_interaction{x}_{y}_option_1", 1);
                array[1] = LocalizationSystem.GetLocalisedValue(majorNPC.NPCName + $"_interaction{x}_{y}_option_2", 1);
                __result = array;
            }
        }
    }

    [HarmonyPatch(typeof(DialogueManager), "RelationshipLevelResponse")]

    public class Patch_RelationshipLevelResponse
    {
        static AccessTools.FieldRef<DialogueManager, MajorNPC> majorNPCRef =
        AccessTools.FieldRefAccess<DialogueManager, MajorNPC>("majorNPC");

        static void Postfix(int state, int textNumber, DialogueManager __instance, ref string __result)
        {
            MajorNPC majorNPC = majorNPCRef(__instance);

            int zeroBased = state - 1;
            int x = (zeroBased / 10) + 1;
            int y = (zeroBased % 10) + 1;

            if (y >= 7 && y <= 10)
            {
                switch (textNumber)
                {
                    case 1: __result = LocalizationSystem.GetLocalisedValue(majorNPC.NPCName + $"_interaction{x}_{y}_response_1", 1);
                    break;
                    case 2: __result = LocalizationSystem.GetLocalisedValue(majorNPC.NPCName + $"_interaction{x}_{y}_response_2", 1);
                    break;
                }
            }
        }
    }
}
