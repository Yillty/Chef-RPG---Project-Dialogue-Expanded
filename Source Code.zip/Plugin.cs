﻿using BepInEx;
using BepInEx.Logging;
using HarmonyLib;

namespace Dialog_Expanded_Starter;

[BepInPlugin("com.chef_rpg_dialogue_expansion", "Chef RPG Dialogue Expansion", "0.01")]
public class StarterPlugin : BaseUnityPlugin
{
    internal static ManualLogSource Log;

    private void Awake()
    {
        Log = base.Logger;
        Log.LogInfo("[Chef RPG Dialogue Expansion] loaded and initialized");
        
        var harmony = new Harmony("com.chef_rpg_dialogue_expansion");
        harmony.PatchAll();
    }
}